import s from './index.module.scss'
import {css} from "lib/customClassName";

export const UserPage = () => {

    return (
        <div className={css(s.UserPage)}>
            UserPage
        </div>
    );
};
