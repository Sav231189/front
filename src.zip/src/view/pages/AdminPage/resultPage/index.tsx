import s from './style.module.scss'
import {css} from "lib/customClassName";

export const ResultPage = () => {

    return (
        <div className={css(s.ResultPage)}>
            ResultPage
        </div>
    );
};
