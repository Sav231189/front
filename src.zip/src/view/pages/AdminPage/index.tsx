import s from './index.module.scss'
import {css} from "lib/customClassName";

export const AdminPage = () => {

    return (
        <div className={css(s.Index)}>
            AdminPage
        </div>
    );
};
