import s from './style.module.scss'
import {css} from "lib/customClassName";

export const PartnerPage = () => {

    return (
        <div className={css(s.PartnerPage)}>
            PartnerPage
        </div>
    );
};
