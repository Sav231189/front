import s from './style.module.scss'
import {css} from "lib/customClassName";

export const TournamentTable = () => {

    return (
        <div className={css(s.TournamentTable)}>
            TournamentTable
        </div>
    );
};
