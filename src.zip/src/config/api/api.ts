export const serverHttp = `http://127.0.0.1:7000`
